Copyright (c) 2011 - 2012 J.P. Holdings Int'l Ltd.

The copyright to all code committed to this repository is retained by J.P. Holdings Int'l Ltd. All code in this repository is the original work of those who have, at any time, been listed as members of this project and agreed to give J.P. Holdings Int'l Ltd all intellectual property rights to their contributions.

See license.txt file for license terms and conditions.
