package org.powerbot.game.api.wrappers;

public interface Identifiable {
	public int getId();
}
