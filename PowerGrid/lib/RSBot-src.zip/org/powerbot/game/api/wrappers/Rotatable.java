package org.powerbot.game.api.wrappers;

public interface Rotatable {
	public int getRotation();

	public int getOrientation();
}
