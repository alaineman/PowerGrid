package org.jace.examples;

@SuppressWarnings("UseOfSystemOutOrSystemErr")
public class StaticTest
{
	static
	{
		System.out.println("Hello World!");
	}
}
