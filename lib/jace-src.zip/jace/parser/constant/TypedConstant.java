package org.jace.parser.constant;

public interface TypedConstant extends Constant
{
	public int getClassIndex();

	public int getNameAndTypeIndex();
}
